'use strict';
var a=angular.module('demoApp');
a.controller('ConCtrl', function() {
    this.friends = ['swathi', 'ramya', 'mou' , 'annupurma' , 'divi'];
});

