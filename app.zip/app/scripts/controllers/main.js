'use strict';

/**
 * @ngdoc function
 * @name demoApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the demoApp
 */
angular.module('demoApp')
    .controller('MainCtrl', function($scope, $http) {
        $scope.data = "Raw denim you probably haven't heard of them jean shorts Austin. Nesciunt tofu stumptown aliqua, retro synth master cleanse. Mustache cliche tempor, williamsburg carles vegan helvetica. Reprehenderit butcher retro keffiyeh dreamcatcher synth. Cosby sweater eu banh mi, qui irure terry richardson ex squid. Aliquip placeat salvia cillum iphone. Seitan aliquip quis cardigan american apparel, butcher voluptate nisi qui."
        $scope.names = ['swathi', 'ramya', 'mounika', 'dinesh', 'sumana', 'hema', 'ravi', 'shikha'];


        $http.get("data/data.json")
            .then(function(response) {
                $scope.mydata = response.data;

                $scope.my = $scope.mydata.Items[0].desc;
            });
    });
